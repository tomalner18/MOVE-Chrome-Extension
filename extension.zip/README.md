# Move Chrome Extension

**This is the github repository for the  *COMP50010* 2nd Year Computing Group Project**


## Features

TO WRITE 
## Installation

TO WRITE

## Usage

TO WRITE

## Authors

jek1918 - Jordan Kisa

kcl3618 - Kian Low

tla19 - Thomas Alner

icm19 - Ioana Mocanu




## License
[MIT](https://choosealicense.com/licenses/mit/)